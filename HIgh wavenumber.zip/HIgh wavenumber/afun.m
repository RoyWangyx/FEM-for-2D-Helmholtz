

function a=afun(t,s)
    a=1;
end
