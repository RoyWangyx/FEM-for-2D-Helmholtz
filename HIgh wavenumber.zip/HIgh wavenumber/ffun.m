function f=ffun(x,y)
f=0;
end