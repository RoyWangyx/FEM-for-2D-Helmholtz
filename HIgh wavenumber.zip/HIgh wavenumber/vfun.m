function [f] =vfun(x,y)
f = 1;
end